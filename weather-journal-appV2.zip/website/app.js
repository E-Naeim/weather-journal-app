/* Global Variables */
const apiKey = ",&appid=fbee4e453443937f89fe71e307e1f7be&units=metric"; // Metric for Celsius
const server = "http://127.0.0.1:8000"; // URL of server
const apiCall = "http://api.openweathermap.org/data/2.5/weather?zip="; // Act as baseURL

const zip = document.getElementById("zip");
const feelings = document.getElementById("feelings");
const temp = document.getElementById("temp");
const date = document.getElementById("date");
const generate = document.getElementById("generate");
const content = document.getElementById("content");

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth() + 1 + "." + d.getDate() + "." + d.getFullYear();

/*Functions*/

// Function to get weather data
const weatherData = async (zipCode) => {
  try {
    const res = await (await fetch(apiCall + zipCode + apiKey)).json();

    if (res.cod != 200) {
      return alert(res.message);
    }

    return res;
  } catch (error) {
    console.log(error);
  }
};

// Post Data
const postData = async (url = "", info = {}) => {
  let res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(info),
  });

  try {
    const newInfo = await res.json();
    return newInfo;
  } catch (error) {
    console.log(error);
  }
};

// Function to update UI with info
async function UpdateUI() {
  const serverResponse = await fetch(server + "/all");
  try {
    const serverData = await serverResponse.json();
    console.log(serverData); // >> result shows feelings as undefined !!

    date.innerHTML = `Date: ${serverData.date}`;
    temp.innerHTML = `Temperature: ${serverData.temp}`;
    content.innerHTML = `Feelings: ${serverData.feelings}`;
  } catch (error) {
    console.log(console.error());
  }
}

function generateData() {
  const zipCode = zip.value;
  const feelingsValue = feelings.value;

  weatherData(zipCode).then((res) => {
    if (res) {
      const {
        main: { temp },
      } = res;

      const info = {
        date: newDate,
        temp: Math.round(temp) + "&deg",
        feelings: feelingsValue,
      };

      console.log(info);
      postData(server + "/add", info);

      UpdateUI();
    }
  });
}

// Add event listener
generate.addEventListener("click", generateData);
